**************************************
[EssETM](https://t.me/EsseTM)
[Developer](Https://T.me/Sudo_Hack)
***************************************
**Installation instructions**
**************************
git clone https://github.com/EsseTM/Esse-Self
**************************
cd E*
**************************
chmod +x E
**************************
./E install
**************************
./E config
**************************
 ## ارسال شماره و تأیید کد و دستور پایین را بزنید

./E login-Cli

**Go To Esse-Self/Bot/bot.lua & edit line 2 and replace sudoID**

**Go To Esse-Self/Bot/utils.lua &Edit line 2&3 and replace SudoID**
*********************************
**Lucnch Self-Bot:**

screen ./Co*
*********************************

[EsseTM](https://telegram.me/EsseTM)
## END Good Luck :)
